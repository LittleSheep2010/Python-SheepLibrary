import sqlite3
import pymysql

from PythonSheep.DataSheep.SQLConnect import SQLConnect
from PythonSheep.ManagerSheep import ManagerSheep

class SQLExecutor:

    __SQLConnectApi = {}
    __SQLDatabaseTypeTemplate = ["Pymysql", "Sqlite3"]
    __SQLDatabaseType = None
    __ManagerSheepSittings = {}

    def __init__(self):
        # 初始化 __ManagerSheepSittings
        self.__ManagerSheepSittings = ManagerSheep.ExportManagerSheepSittings(ManagerSheep())

    def SynchronizeManagerSheepStatus(self, ManagerCore:ManagerSheep):
        self.__ManagerSheepSittings = ManagerCore.ExportManagerSheepSittings()

    def SynchronizeSQLConnectStatus(self, ConnectClass:SQLConnect) -> bool:
        try : SQLConnectApiType = ConnectClass.GetSQLConnectIO()["SQLManagerType"]
        except KeyError: return False

        if SQLConnectApiType == "file":
            self.__SQLDatabaseType = 1; self.__SQLConnectApi = ConnectClass.GetSQLConnectIO()
            return True
        elif SQLConnectApiType == "server":
            self.__SQLDatabaseType = 0; self.__SQLConnectApi = ConnectClass.GetSQLConnectIO()
            return True
        else:
            self.__SQLDatabaseType = None; return False

    def ProcessSQLScript(self, SQLScript:str, CommitChange:bool=False):
        if self.__SQLDatabaseType is None: return 404

        # 链接到数据库
        global SQLConnectIOPoint
        global SQLConnectIOCursor
        if self.__SQLDatabaseType == 0:
            SQLConnectIOPoint = pymysql.connect(host=self.__SQLConnectApi["ConnectHost"],
                                                user=self.__SQLConnectApi["LoginUser"],
                                                password=self.__SQLConnectApi["LoginPassword"],
                                                database=self.__SQLConnectApi["DatabaseName"],
                                                charset=self.__SQLConnectApi["DatabaseCharset"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        if self.__SQLDatabaseType == 1:
            SQLConnectIOPoint = sqlite3.connect(self.__SQLConnectApi["DatabaseFileName"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        # 执行之前输出语句用于 Debug
        if self.__ManagerSheepSittings["DebugOutput"]:
            print("[Python-SheepLibrary](DataSheep-SQLManager) Need run SQL script is: %s" % SQLScript)

        if self.__SQLDatabaseType == 0:
            SQLConnectIOPoint.cursor().execute(SQLScript)

            if CommitChange: SQLConnectIOPoint.commit()

            return SQLConnectIOPoint.cursor().fetchall()
        elif self.__SQLDatabaseType == 1:
            SQLConnectIOCursor.execute(SQLScript)

            if not CommitChange: SQLConnectIOPoint.commit()

            return SQLConnectIOCursor.fetchall()

    def InsertData(self, TableName:str, InsertColmuns:list, InsertValues:list,
                   InsertValuesStrType:list, InsertListBlockList:list=None) -> int:

        if InsertListBlockList is None:
            InsertListBlockList = []

        if self.__SQLDatabaseType is None: return 404

        # 链接到数据库
        global SQLConnectIOPoint
        global SQLConnectIOCursor
        if self.__SQLDatabaseType == 0:
            SQLConnectIOPoint = pymysql.connect(host=self.__SQLConnectApi["ConnectHost"],
                                                user=self.__SQLConnectApi["LoginUser"],
                                                password=self.__SQLConnectApi["LoginPassword"],
                                                database=self.__SQLConnectApi["DatabaseName"],
                                                charset=self.__SQLConnectApi["DatabaseCharset"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        if self.__SQLDatabaseType == 1:
            SQLConnectIOPoint = sqlite3.connect(self.__SQLConnectApi["DatabaseFileName"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        # 判断是否输入正确
        if not len(InsertColmuns) == len(InsertValues) and not len(InsertValues) == len(InsertValuesStrType):
            return 500

        # 判断自动插入
        if len(InsertColmuns) <= 0:
            SQLConnectIOCursor.execute(
                f"select column_name from information_schema.columns "+ \
                "where table_schema='{self.__SQLConnectApi['DatabaseName']}' and table_name='{TableName}';")
            TableColmunsBuffer = SQLConnectIOCursor.fetchall()

            CheckCount = 0
            for TableColmunsBufferCheck in TableColmunsBuffer:
                CheckCount += 1
                if TableColmunsBufferCheck == InsertListBlockList[CheckCount-1]:
                    continue
                else:
                    InsertColmuns.append(TableColmunsBufferCheck[0])

        # 组合 SQL 语句
        # 组合 SQLColmunsFilter
        SQLColmunsFilter = ""
        for InsertColmunsChecker in InsertColmuns:
            SQLColmunsFilter += (InsertColmunsChecker + ", ")

        # 移除尾随字符串
        SQLColmunsFilter = SQLColmunsFilter[:len(SQLColmunsFilter)-2]

        # 组合 SQLValueFilter
        SQLValuesFilter = ""
        for i in range(len(InsertValues)):

            if InsertValuesStrType[i]:
                SQLValuesFilter += ('"' + str(InsertValues[i]) + '", ')
            else:
                SQLValuesFilter += (str(InsertValues[i]) + ", ")

        # 移除尾随字符串
        SQLValuesFilter = SQLValuesFilter[:len(SQLValuesFilter)-2]

        SQLCommand = f"INSERT INTO {TableName}({SQLColmunsFilter}) VALUE({SQLValuesFilter});"

        # 执行之前输出语句用于 Debug
        if self.__ManagerSheepSittings["DebugOutput"]:
            print("[Python-SheepLibrary](DataSheep-SQLManager) Need run SQL script is: %s" % SQLCommand)

        # 执行 SQLCommand
        if self.__SQLDatabaseType == 0:
            SQLConnectIOCursor.execute(SQLCommand)
            SQLConnectIOPoint.commit()
            return 200
        elif self.__SQLDatabaseType == 1:
            SQLConnectIOCursor.execute(SQLCommand)
            SQLConnectIOPoint.commit()
            return 200

    def UpdateData(self, TableName:str, UpdateSetScript:str, WhereScriptUpdate:str):

        # 链接到数据库
        global SQLConnectIOPoint
        global SQLConnectIOCursor
        if self.__SQLDatabaseType == 0:
            SQLConnectIOPoint = pymysql.connect(host=self.__SQLConnectApi["ConnectHost"],
                                                user=self.__SQLConnectApi["LoginUser"],
                                                password=self.__SQLConnectApi["LoginPassword"],
                                                database=self.__SQLConnectApi["DatabaseName"],
                                                charset=self.__SQLConnectApi["DatabaseCharset"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        if self.__SQLDatabaseType == 1:
            SQLConnectIOPoint = sqlite3.connect(self.__SQLConnectApi["DatabaseFileName"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        SQLCommand = f"UPDATE {TableName} SET {UpdateSetScript} WHERE {WhereScriptUpdate};"

        # 执行 SQLCommand
        if self.__SQLDatabaseType == 0:
            SQLConnectIOCursor.execute(SQLCommand)
            SQLConnectIOPoint.commit()
        elif self.__SQLDatabaseType == 1:
            SQLConnectIOCursor.execute(SQLCommand)
            SQLConnectIOPoint.commit()

    def DeleteData(self, TableName:str, WhereScriptDelete:str):


        # 链接到数据库
        global SQLConnectIOPoint
        global SQLConnectIOCursor
        if self.__SQLDatabaseType == 0:
            SQLConnectIOPoint = pymysql.connect(host=self.__SQLConnectApi["ConnectHost"],
                                                user=self.__SQLConnectApi["LoginUser"],
                                                password=self.__SQLConnectApi["LoginPassword"],
                                                database=self.__SQLConnectApi["DatabaseName"],
                                                charset=self.__SQLConnectApi["DatabaseCharset"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        if self.__SQLDatabaseType == 1:
            SQLConnectIOPoint = sqlite3.connect(self.__SQLConnectApi["DatabaseFileName"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        SQLCommand = f"DELETE FROM {TableName} WHERE {WhereScriptDelete};"

        # 执行之前输出语句用于 Debug
        if self.__ManagerSheepSittings["DebugOutput"]:
            print("[Python-SheepLibrary](DataSheep-SQLManager) Need run SQL script is: %s" % SQLCommand)

        # 执行 SQLCommand
        if self.__SQLDatabaseType == 0:
            SQLConnectIOCursor.execute(SQLCommand)
            SQLConnectIOPoint.commit()
        elif self.__SQLDatabaseType == 1:
            SQLConnectIOCursor.execute(SQLCommand)
            SQLConnectIOPoint.commit()

    def GetData(self, TableName:str, SelectColmuns:list):

        # 链接到数据库
        global SQLConnectIOPoint
        global SQLConnectIOCursor
        if self.__SQLDatabaseType == 0:
            SQLConnectIOPoint = pymysql.connect(host=self.__SQLConnectApi["ConnectHost"],
                                                user=self.__SQLConnectApi["LoginUser"],
                                                password=self.__SQLConnectApi["LoginPassword"],
                                                database=self.__SQLConnectApi["DatabaseName"],
                                                charset=self.__SQLConnectApi["DatabaseCharset"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        if self.__SQLDatabaseType == 1:
            SQLConnectIOPoint = sqlite3.connect(self.__SQLConnectApi["DatabaseFileName"])
            SQLConnectIOCursor = SQLConnectIOPoint.cursor()

        # 处理 SelcetColmuns
        if len(SelectColmuns) <= 0:
            SelectColmuns = ["*"]

        SelectColmunsFilter = ""
        for SelectColmunsChecker in SelectColmuns:
            SelectColmunsFilter += (SelectColmunsChecker + ", ")

        # 移除尾随字符串
        SelectColmunsFilter = SelectColmunsFilter[:len(SelectColmunsFilter)-2]

        SQLCommand = f"SELECT {SelectColmunsFilter} FROM {TableName};"

        # 执行之前输出语句用于 Debug
        if self.__ManagerSheepSittings["DebugOutput"]:
            print("[Python-SheepLibrary](DataSheep-SQLManager) Need run SQL script is: %s" % SQLCommand)

        # 执行 SQLCommand
        if self.__SQLDatabaseType == 0:
            SQLConnectIOCursor.execute(SQLCommand)
            return SQLConnectIOCursor.fetchall()

        elif self.__SQLDatabaseType == 1:
            SQLConnectIOCursor.execute(SQLCommand)
            return SQLConnectIOCursor.fetchall()
