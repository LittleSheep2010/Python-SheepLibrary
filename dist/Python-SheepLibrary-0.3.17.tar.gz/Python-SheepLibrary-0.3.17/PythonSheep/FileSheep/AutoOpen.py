import os
import sys
import subprocess

class AutoOpen:

    def UniversalFileOpen_App(self, FilePath:str):
        # Windows 平台
        if sys.platform.startswith("win32"):
            os.startfile(FilePath)

        # Cygwin 平台
        elif sys.platform.startswith("cygwin"):
            return False  # 无法打开

        # MacOS 平台
        elif sys.platform.startswith("darwin"):
            subprocess.call(["open", FilePath])

        # Liunx 平台
        elif sys.platform.startswith("liunx"):
            subprocess.call(["xdg-open", FilePath])