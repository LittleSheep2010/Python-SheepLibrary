from typing import List


class InputFormat:

    def InputLine2List(self, TipsInfo:str="", InputDelimiter:str=" ") -> list:
        getInputList = []

        # 获取输入
        getInput = input(TipsInfo)

        # 处理输入
        getInputList.append(getInput.split(InputDelimiter))

        # 返回输出
        return getInputList