from __future__ import print_function
from setuptools import setup, find_packages
import sys

setup(
    name="PythonSheep",
    version="0.1.2",
    author="LittleSheep_",
    author_email="cadenjiang@outlook.com",
    description="Python Framework.",
    license="MIT",
    url="https://github.com/LittleSheep2010/PythonSheep",
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        "Environment :: App Environment",
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Chinese',
        'Operating System :: MacOS',
        'Operating System :: Microsoft',
        'Operating System :: Unix',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Programming Language :: Python :: 3.8',
    ],
    install_requires=[],
    zip_safe=True,
)
