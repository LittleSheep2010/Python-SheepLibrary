
# JsonWareHouse 类
class JsonWareHouse:
    # uncommit 保存处
    uncommitJsonFileContents_list = []