import os
import sys

# Tips: class PrintFormat only support 'print' function output info
# Tips：class PrintFormat 仅支持 'print' 函数 输出信息
class PrintFormat:

    def UniversalClearScreen(self):

        # Windows 平台
        if sys.platform.startswith("win32"):
            os.system("cls")

        # Cygwin 平台
        elif sys.platform.startswith("cygwin"):
            return False # 无法清屏

        # MacOS 平台
        elif sys.platform.startswith("darwin"):
            os.system("clear")

        # Liunx 平台
        elif sys.platform.startswith("liunx"):
            os.system("clear")

        # 其他平台
        else:
            return False # 无法清屏