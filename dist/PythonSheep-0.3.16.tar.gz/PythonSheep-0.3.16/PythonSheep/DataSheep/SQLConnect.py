import sqlite3
import pymysql
import os

class SQLConnect:

    __SQLConnectApi = {}

    # @NAME Function: ConnectSQLFile
    # @PARA FilePath:str
    # @TODO Connect your SQLDatabase(File) and save connect info
    def ConnectSQLFile(self, FilePath:str) -> bool:
        # 测试文件
        if not os.path.exists(FilePath) and not os.path.isfile(FilePath):
            return False

        self.__SQLConnectApi = {"SQLManagerType": "file", "DatabaseFileName": FilePath}; return True

    # @NAME Function: ConnectSQLDatabase
    # @PARA ConnectDatabase:str, DatabaseHost:str, ConnectUsername:str, ConnectPassword:str
    # @TODO Connect your SQLDatabase(Server) and save connect info
    def ConnectSQLDatabase(self, ConnectDatabase:str, DatabaseHost:str, ConnectUsername:str, ConnectPassword:str, DatabaseCharset:str="utf8") -> int:
        SQLConnectIO = pymysql.connect(host=DatabaseHost, user=ConnectUsername, password=ConnectPassword, database=ConnectDatabase, charset="utf8mb4")

        # 测试
        try:
            SQLConnectIO.ping()
            self.__SQLConnectApi = {"SQLManagerType": "server",
                                    "DatabaseName": ConnectDatabase,
                                    "ConnectHost": DatabaseHost,
                                    "LoginUser": ConnectUsername,
                                    "LoginPassword": ConnectPassword,
                                    "DatabaseCharset": DatabaseCharset}
            return 200

        except : return 404

    def GetSQLConnectIO(self):
        return self.__SQLConnectApi