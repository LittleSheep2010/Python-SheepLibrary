import os
import sys

# Tips: class PrintFormat only support 'print' function output info
# Tips：class PrintFormat 仅支持 'print' 函数 输出信息
class PrintFormat:

    def UniversalClearScreen(self):

        # Windows 平台
        if sys.platform.startswith("win32"):
            os.system("cls")

        # Cygwin 平台
        elif sys.platform.startswith("cygwin"):
            return False # 无法清屏

        # MacOS 平台
        elif sys.platform.startswith("darwin"):
            os.system("clear")

        # Liunx 平台
        elif sys.platform.startswith("liunx"):
            os.system("clear")

        # 其他平台
        else:
            return False # 无法清屏

class ColorfulPrint:

    # ColorList
    __IncludeColorList = [
        {"name": "black", "code": "\033[30m"},
        {"name": "red", "code": "\033[31m"},
        {"name": "green", "code": "\033[32m"},
        {"name": "yello", "code": "\033[33m"},
        {"name": "blue", "code": "\033[34m"},
        {"name": "purple", "code": "\033[35m"},
        {"name": "skyBlue", "code": "\033[36m"},
        {"name": "white", "code": "\033[37m"},

        {"name": "null", "code": "\033[0m"}
    ]

    # 通过 ColorName 设置 PrintColor
    def SetColor(self, ColorName:str):

        for FindingColor in self.__IncludeColorList:

            # 查找
            if ColorName == FindingColor["name"]:

                # 设置颜色
                print(f"{FindingColor['code']}", end=""); return

    # 清除颜色
    def ResetColor(self):

        print(f"{self.__IncludeColorList[len(self.__IncludeColorList)-1]['code']}")