from PythonSheep.IOSheep.PrintFormat import PrintFormat

class ManagerSheep:

    # ManagerSheep 设置
    ManagerSheepSittings = {
        "DebugOutput": False
    }

    # ManagerSheep 设置列表
    __ManagerSheepSittingsList = [
        "DebugOutput"
    ]

    # ManagerSheep 设置函数
    def SetPythonSheepSitting(self,
                              EnableDebugOutput:bool=False):

        self.ManagerSheepSittings = {
            "DebugOutput": EnableDebugOutput
        }


    def ResetPythonSheepSitting(self):

        self.ManagerSheepSittings = {
            "DebugOutput": False
        }


    # 保存 Sitting 函数
    def ExportManagerSheepSittings(self) -> dict:
        return self.ManagerSheepSittings

    # 读取 Sittings 函数
    def ImportManagerSheepSittings(self, ImportSittingsContents:dict, ShowWorkingLog=False) -> bool:

        # 验证是否兼容
        # 检测大小是否相融
        passFlag = False

        if len(self.ManagerSheepSittings) == len(ImportSittingsContents):

            # 继续检测
            # 详细检测
            for i in range(len(self.ManagerSheepSittings)):

                # 测试日志
                print("[PythonSheep] Test import sittings... ")

                try:
                    print(f"[PythonSheep] Trying <{ImportSittingsContents[self.__ManagerSheepSittingsList]}>")
                    passFlag = True

                except KeyError:
                    print(f"[PythonSheep] Config KeyError")
                    passFlag = False

        if ShowWorkingLog:
            print("[PythonSheep] All works complete.")
            input("[PythonSheep] Press Enter key continue rewrite task... ")

            # 清屏
            print("[PythonSheep] Clear screen... ")
            PrintFormat.UniversalClearScreen(PrintFormat())

        if passFlag :
            print("[PythonSheep] Done, rewrite ManagerSheep Config... ")

            # 清屏
            print("[PythonSheep] Clear screen... ")
            PrintFormat.UniversalClearScreen(PrintFormat())

            self.ManagerSheepSittings = ImportSittingsContents; return True

        else : return False
