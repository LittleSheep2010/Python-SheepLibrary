# PythonSheep

This is SheepLibrary Python version
这是 SheepLibrary 的 Python 版本

## 概括 Generalize

This is my collection of scripts library, it may be very large, but it will be very useful
这个是我的使用脚本集合库，可能会非常庞大，但一定会非常有用

## 安装 Install

如何安装这个实用的工具库呢？
How to install this useful tool library?

### 开发版 Dev version

使用 git 命令吧仓库克隆到本地！
Use the git command to clone the repository to the local!

```shell
git clone https://github.com/LittleSheep2010/PythonSheep.git
```

然后 `cd` 到克隆到的目录
Then `cd` to the cloned directory

找到 dict 目录
Find the dict directory

使用这个命令进行安装
Use this command to install

```shell
pip install [File name]
```

或者升级
Or upgrade

```shell
pip install --upgrade [File name]
```

